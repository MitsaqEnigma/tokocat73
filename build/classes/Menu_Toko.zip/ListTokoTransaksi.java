/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Java;

/**
 *
 * @author Miracle
 */
public class ListTokoTransaksi {
    private int kode_barang, jumlah, harga_jual_1_barang, harga_2_jual_barang, harga_jual_3_barang, harga, subtotal;
    private String nama_barang, satuan;

    public int getKode_barang() {
        return kode_barang;
    }

    public void setKode_barang(int kode_barang) {
        this.kode_barang = kode_barang;
    }

    public int getJumlah() {
        return jumlah;
    }

    public void setJumlah(int jumlah) {
        this.jumlah = jumlah;
    }

    public int getHarga_jual_1_barang() {
        return harga_jual_1_barang;
    }

    public void setHarga_jual_1_barang(int harga_jual_1_barang) {
        this.harga_jual_1_barang = harga_jual_1_barang;
    }

    public int getHarga_2_jual_barang() {
        return harga_2_jual_barang;
    }

    public void setHarga_2_jual_barang(int harga_2_jual_barang) {
        this.harga_2_jual_barang = harga_2_jual_barang;
    }

    public int getHarga_jual_3_barang() {
        return harga_jual_3_barang;
    }

    public void setHarga_jual_3_barang(int harga_jual_3_barang) {
        this.harga_jual_3_barang = harga_jual_3_barang;
    }

    public int getHarga() {
        return harga;
    }

    public void setHarga(int harga) {
        this.harga = harga;
    }

    public int getSubtotal() {
        return subtotal;
    }

    public void setSubtotal(int subtotal) {
        this.subtotal = subtotal;
    }

    public String getNama_barang() {
        return nama_barang;
    }

    public void setNama_barang(String nama_barang) {
        this.nama_barang = nama_barang;
    }

    public String getSatuan() {
        return satuan;
    }

    public void setSatuan(String satuan) {
        this.satuan = satuan;
    }
    
}
