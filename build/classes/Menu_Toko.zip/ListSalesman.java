package Java;

public class ListSalesman {
    private String nama_salesman, contact_salesman, telepon_salesman, alamat_salesman, kota_salesman;
    private int no, status;
    private double gaji;

    public double getGaji() {
        return gaji;
    }

    public void setGaji(double gaji) {
        this.gaji = gaji;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public int getNo() {
        return no;
    }

    public void setNo(int no) {
        this.no = no;
    }
    public String getNama_salesman() {
        return nama_salesman;
    }

    public void setNama_salesman(String nama_salesman) {
        this.nama_salesman = nama_salesman;
    }

    public String getContact_salesman() {
        return contact_salesman;
    }

    public void setContact_salesman(String contact_salesman) {
        this.contact_salesman = contact_salesman;
    }

    public String getTelepon_salesman() {
        return telepon_salesman;
    }

    public void setTelepon_salesman(String telepon_salesman) {
        this.telepon_salesman = telepon_salesman;
    }

    public String getAlamat_salesman() {
        return alamat_salesman;
    }

    public void setAlamat_salesman(String alamat_salesman) {
        this.alamat_salesman = alamat_salesman;
    }

    public String getKota_salesman() {
        return kota_salesman;
    }

    public void setKota_salesman(String kota_salesman) {
        this.kota_salesman = kota_salesman;
    }
    
    
}
